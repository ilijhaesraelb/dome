TERMINAL_APPROVED = {
    "Case Was Approved",
    "New Card Is Being Produced",
    "Card Was Delivered To Me By The Post Office",
}

TERMINAL_DENIED = {
    "Case Was Denied",
}

def classify_terminal(status_text: str | None) -> str | None:
    if not status_text:
        return None
    s = status_text.strip()
    if s in TERMINAL_APPROVED:
        return "approved"
    if s in TERMINAL_DENIED:
        return "denied"
    return None
