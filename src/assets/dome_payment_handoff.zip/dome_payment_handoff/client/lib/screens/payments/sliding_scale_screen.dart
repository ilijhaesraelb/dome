import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../state/case_state.dart';
import '../../widgets/dome_appbar.dart';

class SlidingScaleScreen extends StatefulWidget {
  const SlidingScaleScreen({super.key});
  @override
  State<SlidingScaleScreen> createState() => _SlidingScaleScreenState();
}

class _SlidingScaleScreenState extends State<SlidingScaleScreen> {
  final householdCtrl = TextEditingController(text: "1");
  final incomeCtrl = TextEditingController();
  bool onBenefits = false;
  bool wantsWaiver = false;

  double computeDiscount(double monthlyIncome, int householdSize, bool benefits, bool waiver) {
    if (waiver) return 1.0;
    if (benefits) return 0.75;

    // MVP heuristic; replace with real FPL table if desired.
    final perPersonThreshold = 1800.0;
    final threshold = perPersonThreshold * householdSize;

    if (monthlyIncome <= threshold) return 0.9;
    if (monthlyIncome <= threshold * 1.5) return 0.5;
    if (monthlyIncome <= threshold * 2.2) return 0.25;
    return 0.0;
  }

  void continueNext() {
    final cs = context.read<CaseState>();
    final household = int.tryParse(householdCtrl.text.trim()) ?? 1;
    final income = double.tryParse(incomeCtrl.text.trim()) ?? 0.0;

    final discount = computeDiscount(income, household, onBenefits, wantsWaiver);
    cs.slidingDiscount = discount;
    cs.householdSize = household;
    cs.monthlyIncome = income;
    cs.onBenefits = onBenefits;
    cs.requestedWaiver = wantsWaiver;

    Navigator.pushNamed(context, "/checkout");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DomeAppBar(title: "Fee Waiver / Sliding Scale", progress: 0.93, onBack: () => Navigator.pop(context)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            "We never deny services because you can’t pay.\nAnswer a few questions to see your reduced fee.",
            style: TextStyle(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: householdCtrl,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: "Household size", border: OutlineInputBorder()),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: incomeCtrl,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: "Gross monthly household income (USD)", border: OutlineInputBorder()),
          ),
          const SizedBox(height: 10),
          SwitchListTile(
            value: onBenefits,
            onChanged: (v) => setState(() => onBenefits = v),
            title: const Text("I currently receive public benefits"),
          ),
          SwitchListTile(
            value: wantsWaiver,
            onChanged: (v) => setState(() => wantsWaiver = v),
            title: const Text("I need a full fee waiver"),
            subtitle: const Text("You will not be denied services."),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton(onPressed: continueNext, child: const Text("Continue to Checkout")),
          )
        ],
      ),
    );
  }
}
