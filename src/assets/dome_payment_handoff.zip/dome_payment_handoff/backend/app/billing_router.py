import stripe
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .db import get_db
from .deps import auth_user
from .settings import settings
from .models import User
from .models_billing import CaseBilling

stripe.api_key = settings.STRIPE_SECRET_KEY
router = APIRouter(prefix="/v1/billing", tags=["billing"])

def _get_or_create_billing(db: Session, case_id: str, user_id: str) -> CaseBilling:
    b = db.query(CaseBilling).filter(CaseBilling.case_id==case_id, CaseBilling.user_id==user_id).first()
    if not b:
        b = CaseBilling(case_id=case_id, user_id=user_id)
        db.add(b); db.commit(); db.refresh(b)
    return b

def _ensure_customer(db: Session, b: CaseBilling, user_email: str) -> str:
    if b.stripe_customer_id:
        return b.stripe_customer_id
    c = stripe.Customer.create(email=user_email, metadata={"user_id": b.user_id})
    b.stripe_customer_id = c["id"]
    b.updated_at = datetime.utcnow()
    db.commit()
    return b.stripe_customer_id

@router.post("/cases/{case_id}/subscribe")
def create_case_subscription_checkout(case_id: str, user_id=Depends(auth_user), db: Session = Depends(get_db)):
    if not settings.STRIPE_SECRET_KEY or not settings.STRIPE_PRICE_CASE_SUB:
        raise HTTPException(500, "Stripe not configured (missing STRIPE_SECRET_KEY or STRIPE_PRICE_CASE_SUB).")

    u = db.query(User).filter(User.id==user_id).first()
    if not u:
        raise HTTPException(404, "User not found")

    b = _get_or_create_billing(db, case_id, user_id)
    cust_id = _ensure_customer(db, b, u.email)

    session = stripe.checkout.Session.create(
        mode="subscription",
        customer=cust_id,
        line_items=[{"price": settings.STRIPE_PRICE_CASE_SUB, "quantity": 1}],
        success_url=settings.STRIPE_SUCCESS_URL,
        cancel_url=settings.STRIPE_CANCEL_URL,
        metadata={"case_id": case_id, "user_id": user_id, "billing_id": b.id},
    )

    b.last_checkout_session_id = session["id"]
    b.last_payment_mode = "subscription"
    b.updated_at = datetime.utcnow()
    db.commit()

    return {"checkout_url": session["url"], "session_id": session["id"]}

@router.post("/cases/{case_id}/pay-one-time")
def create_one_time_checkout(case_id: str, body: dict, user_id=Depends(auth_user), db: Session = Depends(get_db)):
    if not settings.STRIPE_SECRET_KEY:
        raise HTTPException(500, "Stripe not configured (missing STRIPE_SECRET_KEY).")

    u = db.query(User).filter(User.id==user_id).first()
    if not u:
        raise HTTPException(404, "User not found")

    amount_cents = int(body.get("amount_cents", 0))
    currency = body.get("currency", "usd")
    purpose = body.get("purpose", "service")

    if amount_cents <= 0:
        raise HTTPException(400, "amount_cents required")

    b = _get_or_create_billing(db, case_id, user_id)
    cust_id = _ensure_customer(db, b, u.email)

    session = stripe.checkout.Session.create(
        mode="payment",
        customer=cust_id,
        line_items=[{
            "price_data": {
                "currency": currency,
                "unit_amount": amount_cents,
                "product_data": {"name": f"D.O.M.E. {purpose.replace('_',' ').title()} Fee"}
            },
            "quantity": 1
        }],
        success_url=settings.STRIPE_SUCCESS_URL,
        cancel_url=settings.STRIPE_CANCEL_URL,
        metadata={"case_id": case_id, "user_id": user_id, "billing_id": b.id, "purpose": purpose},
    )

    b.last_checkout_session_id = session["id"]
    b.last_payment_mode = "payment"
    b.updated_at = datetime.utcnow()
    db.commit()

    return {"checkout_url": session["url"], "session_id": session["id"]}
