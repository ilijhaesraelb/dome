import stripe
from fastapi import APIRouter, Query, HTTPException
from .settings import settings

stripe.api_key = settings.STRIPE_SECRET_KEY
router = APIRouter(prefix="/v1/billing", tags=["billing"])

@router.get("/checkout-session")
def get_checkout_session(session_id: str = Query(...)):
    if not settings.STRIPE_SECRET_KEY:
        raise HTTPException(500, "Stripe not configured (missing STRIPE_SECRET_KEY).")
    session = stripe.checkout.Session.retrieve(session_id)
    return {
        "id": session["id"],
        "mode": session.get("mode"),
        "payment_status": session.get("payment_status"),
        "status": session.get("status"),
        "subscription": session.get("subscription"),
        "customer": session.get("customer"),
        "metadata": session.get("metadata"),
    }
