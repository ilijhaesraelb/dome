from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .db import get_db
from .deps import auth_user
from .models_notify import DeviceToken

router = APIRouter(prefix="/v1/notify", tags=["notify"])

@router.post("/register")
def register_token(body: dict, user_id=Depends(auth_user), db: Session = Depends(get_db)):
    token = body.get("token")
    platform = body.get("platform", "web")
    if not token:
        raise HTTPException(400, "missing token")

    existing = db.query(DeviceToken).filter(DeviceToken.user_id==user_id, DeviceToken.token==token).first()
    if existing:
        existing.is_active = True
        existing.platform = platform
    else:
        db.add(DeviceToken(user_id=user_id, token=token, platform=platform))
    db.commit()
    return {"ok": True}
