import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../state/case_state.dart';
import '../../widgets/dome_appbar.dart';

class PricingScreen extends StatelessWidget {
  const PricingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final caseState = context.watch<CaseState>();

    return Scaffold(
      appBar: DomeAppBar(title: "Pricing", progress: 0.90, onBack: () => Navigator.pop(context)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _PlanCard(
            title: "Case Subscription",
            price: "\$3.00 / month",
            subtitle: "Covers your active case until approved or denied.",
            bullets: const [
              "Voice-guided form filling",
              "Save progress anytime",
              "Packet PDF export",
              "Embassy/USCIS locator",
              "Cancel anytime",
            ],
            highlight: true,
            onSelect: () {
              caseState.selectedPlan = CasePlan.subscriptionOnly;
              Navigator.pushNamed(context, "/sliding-scale");
            },
          ),
          const SizedBox(height: 12),
          const Text("Optional flat-fee upgrades", style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          _PlanCard(
            title: "Self-Prep Assisted (per package)",
            price: caseState.packagePriceLabel(),
            subtitle: "AI voice fill + neat PDF packet.",
            bullets: const ["Auto-fill forms", "Upload evidence", "Final PDF bundle"],
            onSelect: () {
              caseState.selectedPlan = CasePlan.selfPrepFlat;
              Navigator.pushNamed(context, "/sliding-scale");
            },
          ),
          _PlanCard(
            title: "Guided Review by Accredited Rep",
            price: caseState.reviewPriceLabel(),
            subtitle: "Optional legal review + corrections.",
            bullets: const ["Accredited review", "One correction round", "Readiness confirmation"],
            onSelect: () {
              caseState.selectedPlan = CasePlan.reviewFlat;
              Navigator.pushNamed(context, "/sliding-scale");
            },
          ),
          const SizedBox(height: 16),
          Text(
            "If you cannot pay, you can request a full fee waiver.\nNo one is denied services for inability to pay.",
            style: TextStyle(color: Colors.grey.shade700),
          )
        ],
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  final String title, price, subtitle;
  final List<String> bullets;
  final bool highlight;
  final VoidCallback onSelect;

  const _PlanCard({
    required this.title,
    required this.price,
    required this.subtitle,
    required this.bullets,
    required this.onSelect,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: highlight ? Colors.deepPurple.shade50 : null,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800))),
              Text(price, style: const TextStyle(fontWeight: FontWeight.w800)),
            ]),
            const SizedBox(height: 4),
            Text(subtitle),
            const SizedBox(height: 8),
            ...bullets.map((b) => Row(
                  children: [
                    const Icon(Icons.check, size: 16),
                    const SizedBox(width: 6),
                    Expanded(child: Text(b)),
                  ],
                )),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: FilledButton(onPressed: onSelect, child: const Text("Continue")),
            )
          ],
        ),
      ),
    );
  }
}
