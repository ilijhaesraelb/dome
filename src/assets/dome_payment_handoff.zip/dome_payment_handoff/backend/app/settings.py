import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./dome.db")

    # Stripe
    STRIPE_SECRET_KEY: str = os.getenv("STRIPE_SECRET_KEY", "")
    STRIPE_WEBHOOK_SECRET: str = os.getenv("STRIPE_WEBHOOK_SECRET", "")
    STRIPE_PRICE_CASE_SUB: str = os.getenv("STRIPE_PRICE_CASE_SUB", "")
    STRIPE_SUCCESS_URL: str = os.getenv("STRIPE_SUCCESS_URL", "https://domeapp.org/pay/success?session_id={CHECKOUT_SESSION_ID}")
    STRIPE_CANCEL_URL: str = os.getenv("STRIPE_CANCEL_URL", "https://domeapp.org/pay/cancel")

    # Torch
    TORCH_ENV: str = os.getenv("TORCH_ENV", "sandbox")  # sandbox | prod
    TORCH_CLIENT_ID: str = os.getenv("TORCH_CLIENT_ID", "")
    TORCH_CLIENT_SECRET: str = os.getenv("TORCH_CLIENT_SECRET", "")
    TORCH_TOKEN_URL_SANDBOX: str = os.getenv("TORCH_TOKEN_URL_SANDBOX", "https://api-int.uscis.gov/oauth/accesstoken")
    TORCH_BASE_URL_SANDBOX: str = os.getenv("TORCH_BASE_URL_SANDBOX", "https://api-int.uscis.gov")
    TORCH_TOKEN_URL_PROD: str = os.getenv("TORCH_TOKEN_URL_PROD", "")
    TORCH_BASE_URL_PROD: str = os.getenv("TORCH_BASE_URL_PROD", "")

    # Firebase (push notifications) - optional
    FIREBASE_SA_JSON: str = os.getenv("FIREBASE_SA_JSON", "")

settings = Settings()
