from fastapi import Depends, Header, HTTPException
from sqlalchemy.orm import Session
from .db import get_db
from .models import User

def auth_user(x_user_id: str | None = Header(default=None), db: Session = Depends(get_db)) -> str:
    # Replace with your real auth (JWT). This is a dev stub for integration testing.
    if not x_user_id:
        raise HTTPException(401, "Missing X-User-Id header (stub auth).")
    u = db.query(User).filter(User.id==x_user_id).first()
    if not u:
        raise HTTPException(401, "Unknown user (stub auth).")
    return u.id

def require_admin(user_id: str = Depends(auth_user), db: Session = Depends(get_db)) -> str:
    u = db.query(User).filter(User.id==user_id).first()
    if not u or not u.is_admin:
        raise HTTPException(403, "Admin required.")
    return u.id
