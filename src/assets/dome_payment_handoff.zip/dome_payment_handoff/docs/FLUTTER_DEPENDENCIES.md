# Flutter dependencies needed for these screens

Add to pubspec.yaml:

```yaml
dependencies:
  provider: ^6.1.2
  http: ^1.2.2
  url_launcher: ^6.3.0
  firebase_core: ^3.6.0
  firebase_messaging: ^15.1.3
```

Also ensure Firebase is configured for iOS/Android/Web in your Flutter project.
