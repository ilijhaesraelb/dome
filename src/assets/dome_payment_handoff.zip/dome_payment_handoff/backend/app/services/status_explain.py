EXPLANATIONS = {
    "Case Was Received": "USCIS received your application and issued a receipt number. Next step is usually biometrics or review.",
    "Biometrics Appointment Was Scheduled": "USCIS scheduled your fingerprints/photo appointment. Go on the date in your notice.",
    "Request For Evidence Was Sent": "USCIS needs more proof. Read the RFE letter carefully and respond before the deadline.",
    "Case Is Being Actively Reviewed By USCIS": "An officer is reviewing your case now. This is normal and can take time.",
    "Case Was Approved": "Your case is approved. Watch for your approval notice and any cards/documents in the mail.",
    "Case Was Denied": "Your case was denied. You should talk to an Accredited Rep or attorney to review options.",
}

def explain_status(status_text: str | None) -> str:
    if not status_text:
        return "No status yet."
    return EXPLANATIONS.get(status_text, "This is a USCIS status update. If you're unsure, ask us to explain it in plain terms.")
