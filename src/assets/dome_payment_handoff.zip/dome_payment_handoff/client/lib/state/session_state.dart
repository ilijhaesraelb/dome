import 'package:flutter/foundation.dart';

class SessionState extends ChangeNotifier {
  String userId;
  bool isAdmin;

  SessionState({required this.userId, this.isAdmin = false});
}
