import 'package:flutter/material.dart';

class DomeAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final double progress;
  final VoidCallback? onBack;

  const DomeAppBar({super.key, required this.title, this.progress = 0, this.onBack});

  @override
  Size get preferredSize => const Size.fromHeight(56);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      leading: onBack == null
          ? null
          : IconButton(icon: const Icon(Icons.arrow_back), onPressed: onBack),
      title: Text(title),
      bottom: progress > 0
          ? PreferredSize(
              preferredSize: const Size.fromHeight(4),
              child: LinearProgressIndicator(value: progress),
            )
          : null,
    );
  }
}
