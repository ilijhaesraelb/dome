import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../services/api.dart';
import '../../state/session_state.dart';
import '../../state/case_state.dart';
import '../../widgets/dome_appbar.dart';

class PayScreen extends StatefulWidget {
  const PayScreen({super.key});
  @override
  State<PayScreen> createState() => _PayScreenState();
}

class _PayScreenState extends State<PayScreen> {
  bool loading = false;
  String? error;

  Future<void> startSubscription() async {
    setState(() { loading = true; error = null; });
    try {
      final s = context.read<SessionState>();
      final cs = context.read<CaseState>();
      final res = await Api.post("/v1/billing/cases/${cs.caseId}/subscribe", s, {});
      if (res.statusCode != 200) throw Exception(res.body);
      final data = jsonDecode(res.body);
      final url = data["checkout_url"];
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (e) {
      setState(() => error = "$e");
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DomeAppBar(title: "Pay / Subscribe", progress: 0.98, onBack: () => Navigator.pop(context)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text("Start your $3/month case subscription (auto-stops when approved/denied)."),
            const SizedBox(height: 12),
            if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: loading ? null : startSubscription,
                child: loading ? const CircularProgressIndicator() : const Text("Start $3/month subscription"),
              ),
            )
          ],
        ),
      ),
    );
  }
}
