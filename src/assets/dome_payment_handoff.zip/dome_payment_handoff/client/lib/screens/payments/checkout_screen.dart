import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../state/case_state.dart';
import '../../widgets/dome_appbar.dart';

class CheckoutScreen extends StatelessWidget {
  const CheckoutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = context.watch<CaseState>();
    final baseNonprofitFee = cs.baseNonprofitFee();
    final discount = cs.slidingDiscount ?? 0.0;
    final nonprofitFee = baseNonprofitFee * (1.0 - discount);

    return Scaffold(
      appBar: DomeAppBar(title: "Checkout", progress: 0.96, onBack: () => Navigator.pop(context)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text("Your fees", style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          _Line("AREI GROUP nonprofit fee", baseNonprofitFee),
          if (discount > 0) _Line("Sliding-scale reduction", -baseNonprofitFee * discount),
          const Divider(),
          _Line("Nonprofit fee due today", nonprofitFee),
          const SizedBox(height: 12),
          const Text("Government filing fees (paid to USCIS/DOS)", style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          _Line("Estimated government fees", cs.estimatedGovtFeeUsd),
          const SizedBox(height: 8),
          Text(
            "Government fees are separate and are paid directly to USCIS/DOS unless you choose otherwise.",
            style: TextStyle(color: Colors.grey.shade700, fontSize: 12),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () => Navigator.pushNamed(context, "/pay"),
              child: const Text("Continue to Payment"),
            ),
          ),
        ],
      ),
    );
  }
}

class _Line extends StatelessWidget {
  final String label;
  final double amount;
  const _Line(this.label, this.amount);

  @override
  Widget build(BuildContext context) {
    final isNeg = amount < 0;
    return Row(
      children: [
        Expanded(child: Text(label)),
        Text(
          "${isNeg ? "-" : ""}\$${amount.abs().toStringAsFixed(2)}",
          style: TextStyle(fontWeight: FontWeight.w700, color: isNeg ? Colors.green : null),
        )
      ],
    );
  }
}
