from sqlalchemy import Column, String, Boolean
from .db import Base

class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True)
    email = Column(String, unique=True, index=True)
    is_admin = Column(Boolean, default=False)
