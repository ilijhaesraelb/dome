from datetime import datetime
import stripe
from sqlalchemy.orm import Session
from ..settings import settings
from ..models_billing import CaseBilling

stripe.api_key = settings.STRIPE_SECRET_KEY

def cancel_case_subscription(db: Session, billing: CaseBilling, reason: str) -> None:
    if billing.stripe_subscription_id:
        stripe.Subscription.cancel(billing.stripe_subscription_id)
    billing.is_active = False
    billing.ended_reason = reason
    billing.updated_at = datetime.utcnow()
    db.commit()
