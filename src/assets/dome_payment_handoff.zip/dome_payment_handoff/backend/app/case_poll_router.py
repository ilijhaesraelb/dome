from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .db import get_db
from .deps import auth_user
from .models_cases import Case
from .models_billing import CaseBilling
from .models_timeline import CaseStatusEvent
from .services.torch_client import torch_client
from .services.case_status_rules import classify_terminal
from .services.subscription_cancel import cancel_case_subscription
from .services.push import send_status_push

router = APIRouter(prefix="/v1/cases", tags=["cases"])

@router.post("/{case_id}/poll-status")
def poll_status(case_id: str, user_id=Depends(auth_user), db: Session = Depends(get_db)):
    c = db.query(Case).filter(Case.id==case_id, Case.user_id==user_id).first()
    if not c:
        raise HTTPException(404, "Case not found")
    if not c.receipt_number:
        raise HTTPException(400, "No USCIS receipt number on case")

    data = torch_client.request("GET", "/case-status/v1/cases", params={"receiptNumber": c.receipt_number})
    status_text = data.get("caseStatus") or data.get("status") or ""

    old_status = c.latest_status
    c.latest_status = status_text
    c.latest_status_raw = data
    db.commit()

    if status_text and status_text != old_status:
        ev = CaseStatusEvent(
            case_id=c.id,
            user_id=c.user_id,
            status_text=status_text,
            status_code=data.get("caseStatusCode") or data.get("statusCode"),
            raw_jsonb=data,
            occurred_at=datetime.utcnow(),
            source="TORCH",
        )
        db.add(ev)
        db.commit()
        send_status_push(db, c.user_id, c.id, status_text)

    terminal = classify_terminal(status_text)
    if terminal:
        b = db.query(CaseBilling).filter(CaseBilling.case_id==case_id, CaseBilling.user_id==user_id, CaseBilling.is_active==True).first()
        if b:
            cancel_case_subscription(db, b, terminal)

    return {"status": status_text, "terminal": terminal, "raw": data}
