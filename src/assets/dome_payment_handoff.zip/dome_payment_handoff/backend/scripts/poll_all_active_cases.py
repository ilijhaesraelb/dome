"""Cron-friendly poller that checks all active subscriptions and cancels on terminal status.

Run e.g. every 12 hours:
  python -m scripts.poll_all_active_cases
"""
from sqlalchemy.orm import Session
from app.db import SessionLocal
from app.models_cases import Case
from app.models_billing import CaseBilling
from app.models_timeline import CaseStatusEvent
from app.services.torch_client import torch_client
from app.services.case_status_rules import classify_terminal
from app.services.subscription_cancel import cancel_case_subscription
from app.services.push import send_status_push
from datetime import datetime

def main():
    db: Session = SessionLocal()
    try:
        billings = db.query(CaseBilling).filter(CaseBilling.is_active==True).all()
        for b in billings:
            c = db.query(Case).filter(Case.id==b.case_id).first()
            if not c or not c.receipt_number:
                continue

            data = torch_client.request("GET", "/case-status/v1/cases", params={"receiptNumber": c.receipt_number})
            status_text = data.get("caseStatus") or data.get("status") or ""
            old_status = c.latest_status

            c.latest_status = status_text
            c.latest_status_raw = data
            db.commit()

            if status_text and status_text != old_status:
                ev = CaseStatusEvent(case_id=c.id, user_id=c.user_id, status_text=status_text,
                                     status_code=data.get("caseStatusCode") or data.get("statusCode"),
                                     raw_jsonb=data, occurred_at=datetime.utcnow(), source="TORCH")
                db.add(ev); db.commit()
                send_status_push(db, c.user_id, c.id, status_text)

            terminal = classify_terminal(status_text)
            if terminal:
                cancel_case_subscription(db, b, terminal)
    finally:
        db.close()

if __name__ == "__main__":
    main()
