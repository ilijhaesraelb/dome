import 'dart:convert';
import 'package:http/http.dart' as http;
import '../state/session_state.dart';

class Api {
  static const String baseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://localhost:8000');

  static Future<http.Response> get(String path, SessionState s) async {
    return http.get(Uri.parse('$baseUrl$path'), headers: _headers(s));
  }

  static Future<http.Response> post(String path, SessionState s, Map<String, dynamic> body) async {
    return http.post(
      Uri.parse('$baseUrl$path'),
      headers: _headers(s),
      body: jsonEncode(body),
    );
  }

  static Map<String, String> _headers(SessionState s) => {
        'Content-Type': 'application/json',
        'X-User-Id': s.userId, // stub auth header; replace with Authorization Bearer token
      };
}
