from fastapi import FastAPI
from .db import Base, engine
from . import models, models_cases, models_billing, models_notify, models_timeline
from .billing_router import router as billing_router
from .stripe_webhook import router as stripe_webhook_router
from .billing_verify_router import router as billing_verify_router
from .notify_router import router as notify_router
from .admin_billing_router import router as admin_billing_router
from .case_poll_router import router as case_poll_router
from .timeline_router import router as timeline_router

def create_app() -> FastAPI:
    Base.metadata.create_all(bind=engine)
    app = FastAPI(title="D.O.M.E. Payment + Status Integration")

    app.include_router(billing_router)
    app.include_router(billing_verify_router)
    app.include_router(stripe_webhook_router)
    app.include_router(notify_router)
    app.include_router(admin_billing_router)
    app.include_router(case_poll_router)
    app.include_router(timeline_router)

    @app.get("/health")
    def health():
        return {"ok": True}

    return app

app = create_app()
