from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .db import get_db
from .deps import auth_user
from .models_cases import Case
from .models_timeline import CaseStatusEvent
from .services.status_explain import explain_status

router = APIRouter(prefix="/v1/timeline", tags=["timeline"])

@router.get("/cases/{case_id}")
def get_timeline(case_id: str, user_id=Depends(auth_user), db: Session = Depends(get_db)):
    c = db.query(Case).filter(Case.id==case_id, Case.user_id==user_id).first()
    if not c:
        raise HTTPException(404, "Case not found")

    events = db.query(CaseStatusEvent).filter(CaseStatusEvent.case_id==case_id).order_by(CaseStatusEvent.occurred_at.asc()).all()

    return {
        "case_id": case_id,
        "receipt_number": c.receipt_number,
        "latest_status": c.latest_status,
        "events": [{
            "id": e.id,
            "status_text": e.status_text,
            "status_code": e.status_code,
            "occurred_at": e.occurred_at.isoformat(),
            "source": e.source,
            "plain_explanation": explain_status(e.status_text),
        } for e in events]
    }
