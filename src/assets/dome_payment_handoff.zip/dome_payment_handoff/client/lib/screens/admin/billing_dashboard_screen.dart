import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/api.dart';
import '../../state/session_state.dart';

class BillingDashboardScreen extends StatefulWidget {
  const BillingDashboardScreen({super.key});
  @override
  State<BillingDashboardScreen> createState() => _BillingDashboardScreenState();
}

class _BillingDashboardScreenState extends State<BillingDashboardScreen> {
  bool loading = true;
  Map summary = {};
  List active = [];
  String? error;

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final s = context.read<SessionState>();
      final sumRes = await Api.get("/v1/admin/billing/summary", s);
      final actRes = await Api.get("/v1/admin/billing/active", s);
      if (sumRes.statusCode != 200) throw Exception(sumRes.body);
      if (actRes.statusCode != 200) throw Exception(actRes.body);
      summary = jsonDecode(sumRes.body);
      active = (jsonDecode(actRes.body)["results"] as List);
    } catch (e) {
      error = "$e";
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => load());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Billing Dashboard")),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text(error!))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    _StatCard("Active subscriptions", "${summary["active_subscriptions"] ?? 0}"),
                    _StatCard("MRR (USD)", "\$${summary["mrr_usd"] ?? 0}"),
                    const SizedBox(height: 12),
                    const Text("Ended reasons", style: TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    ...((summary["ended_breakdown"] ?? {}) as Map).entries.map((e) => Text("${e.key}: ${e.value}")),
                    const SizedBox(height: 16),
                    const Text("Active cases", style: TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    ...active.map((r) => Card(
                          child: ListTile(
                            title: Text("Case: ${r["case_id"]}"),
                            subtitle: Text("Sub: ${r["stripe_subscription_id"] ?? ""}\nUser: ${r["user_id"]}"),
                          ),
                        )),
                  ],
                ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label, value;
  const _StatCard(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(label),
        trailing: Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
      ),
    );
  }
}
