from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from .db import get_db
from .deps import require_admin
from .models_billing import CaseBilling

router = APIRouter(prefix="/v1/admin/billing", tags=["admin-billing"])

@router.get("/summary")
def billing_summary(admin_id=Depends(require_admin), db: Session = Depends(get_db)):
    active_count = db.query(func.count(CaseBilling.id)).filter(CaseBilling.is_active==True).scalar() or 0
    ended = db.query(CaseBilling.ended_reason, func.count(CaseBilling.id))\
              .filter(CaseBilling.is_active==False)\
              .group_by(CaseBilling.ended_reason).all()
    mrr = active_count * 3.00
    return {
        "active_subscriptions": active_count,
        "mrr_usd": round(mrr, 2),
        "ended_breakdown": { (k or "unknown"): v for k, v in ended },
    }

@router.get("/active")
def list_active(admin_id=Depends(require_admin), db: Session = Depends(get_db)):
    rows = db.query(CaseBilling).filter(CaseBilling.is_active==True).order_by(CaseBilling.created_at.desc()).limit(200).all()
    return {"results": [{
        "id": r.id,
        "case_id": r.case_id,
        "user_id": r.user_id,
        "stripe_subscription_id": r.stripe_subscription_id,
        "created_at": r.created_at.isoformat(),
    } for r in rows]}
