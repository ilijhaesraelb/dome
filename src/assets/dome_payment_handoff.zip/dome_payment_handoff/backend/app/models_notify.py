from sqlalchemy import Column, String, DateTime, ForeignKey, Boolean, UniqueConstraint
from datetime import datetime
import uuid
from .db import Base

def uid(): return str(uuid.uuid4())

class DeviceToken(Base):
    __tablename__ = "device_tokens"
    id = Column(String, primary_key=True, default=uid)
    user_id = Column(String, ForeignKey("users.id"), index=True)
    token = Column(String, index=True)
    platform = Column(String)  # ios|android|web
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (UniqueConstraint("user_id", "token", name="uq_user_token"),)
