# D.O.M.E. Payment Integration (Developer Handoff)

## What this package contains
- Stripe Checkout Subscription ($3/month per case)
- Optional one-time payments (flat fees)
- Stripe webhook handler (signature verified)
- Admin billing summary endpoints
- Torch polling endpoint + cron poller
- Push notifications on status change (Firebase Admin SDK; optional)
- Timeline/history endpoint

## Quick start (local)
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Fill Stripe + Torch keys
uvicorn app.main:app --reload --port 8000
```

## Stub authentication (for quick testing)
This sample uses a stub header auth:
- Send `X-User-Id: <user_id>` for user endpoints
- Send `X-User-Id: <admin_user_id>` for admin endpoints, with user.is_admin=true

Replace `app/deps.py` with your JWT auth in production.

## Stripe setup
1. Create a Product+Price for $3/month in Stripe (Price ID -> STRIPE_PRICE_CASE_SUB)
2. Configure webhook URL: `/v1/webhooks/stripe`
3. Copy `STRIPE_WEBHOOK_SECRET` (whsec_...) into env

## Key endpoints
- POST `/v1/billing/cases/{case_id}/subscribe` -> {checkout_url}
- POST `/v1/billing/cases/{case_id}/pay-one-time` -> {checkout_url}
- POST `/v1/webhooks/stripe`
- GET  `/v1/admin/billing/summary`
- POST `/v1/cases/{case_id}/poll-status`
- GET  `/v1/timeline/cases/{case_id}`

## Auto-cancel rule
When Torch status becomes terminal `approved` or `denied`, subscription is canceled automatically.

## Firebase push (optional)
Set `FIREBASE_SA_JSON` to a service-account json file path.
If unset, pushes are a no-op (safe).

