from sqlalchemy import Column, String, DateTime, ForeignKey, JSON, Index
from datetime import datetime
import uuid
from .db import Base

def uid(): return str(uuid.uuid4())

class CaseStatusEvent(Base):
    __tablename__ = "case_status_events"
    id = Column(String, primary_key=True, default=uid)
    case_id = Column(String, ForeignKey("cases.id"), index=True)
    user_id = Column(String, ForeignKey("users.id"), index=True)
    status_text = Column(String, index=True)
    status_code = Column(String, nullable=True)
    source = Column(String, default="TORCH")
    occurred_at = Column(DateTime, default=datetime.utcnow)
    raw_jsonb = Column(JSON, default={})

Index("ix_case_events_case_time", CaseStatusEvent.case_id, CaseStatusEvent.occurred_at)
