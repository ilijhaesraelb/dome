from sqlalchemy import Column, String, DateTime, ForeignKey, JSON
from datetime import datetime
from .db import Base

class Case(Base):
    __tablename__ = "cases"
    id = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey("users.id"), index=True)
    receipt_number = Column(String, nullable=True)
    latest_status = Column(String, nullable=True)
    latest_status_raw = Column(JSON, default={})
    created_at = Column(DateTime, default=datetime.utcnow)
