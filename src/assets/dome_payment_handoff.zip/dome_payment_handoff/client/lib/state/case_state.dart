import 'package:flutter/foundation.dart';

enum CasePlan { subscriptionOnly, selfPrepFlat, reviewFlat }

class CaseState extends ChangeNotifier {
  String caseId;
  List<String> selectedForms;

  CasePlan selectedPlan = CasePlan.subscriptionOnly;

  double? slidingDiscount; // 0.0..1.0
  int householdSize = 1;
  double monthlyIncome = 0;
  bool onBenefits = false;
  bool requestedWaiver = false;

  double estimatedGovtFeeUsd = 0;
  bool payGovtFeesThroughApp = false;

  CaseState({required this.caseId, this.selectedForms = const []});

  double baseNonprofitFee() {
    switch (selectedPlan) {
      case CasePlan.subscriptionOnly:
        return 0;
      case CasePlan.selfPrepFlat:
        return packageFlatFee();
      case CasePlan.reviewFlat:
        return reviewFlatFee();
    }
  }

  double packageFlatFee() {
    if (selectedForms.contains('DS-160')) return 40;
    if (selectedForms.contains('I-765')) return 60;
    if (selectedForms.contains('I-130')) return 75;
    if (selectedForms.contains('I-485')) return 90;
    return 50;
  }

  double reviewFlatFee() {
    if (selectedForms.contains('DS-160')) return 200;
    if (selectedForms.contains('I-765')) return 250;
    if (selectedForms.contains('I-130')) return 350;
    if (selectedForms.contains('I-485')) return 450;
    return 300;
  }

  String packagePriceLabel() => '\$${packageFlatFee().toStringAsFixed(0)} per package';
  String reviewPriceLabel() => '\$${reviewFlatFee().toStringAsFixed(0)} per case';
}
