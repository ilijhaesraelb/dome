"""Firebase push sender (optional).

If FIREBASE_SA_JSON is not configured, send_status_push is a no-op.
"""
from __future__ import annotations
from sqlalchemy.orm import Session
from ..settings import settings
from ..models_notify import DeviceToken

_initialized = False
_messaging = None

def _init_firebase():
    global _initialized, _messaging
    if _initialized:
        return
    _initialized = True
    if not settings.FIREBASE_SA_JSON:
        return
    import firebase_admin
    from firebase_admin import credentials, messaging
    cred = credentials.Certificate(settings.FIREBASE_SA_JSON)
    firebase_admin.initialize_app(cred)
    _messaging = messaging

def send_status_push(db: Session, user_id: str, case_id: str, status_text: str) -> int:
    _init_firebase()
    if _messaging is None:
        return 0

    tokens = db.query(DeviceToken).filter(DeviceToken.user_id==user_id, DeviceToken.is_active==True).all()
    if not tokens:
        return 0
    reg_tokens = [t.token for t in tokens]

    msg = _messaging.MulticastMessage(
        notification=_messaging.Notification(title="USCIS Case Update", body=status_text),
        data={"case_id": case_id, "status": status_text},
        tokens=reg_tokens,
    )
    resp = _messaging.send_multicast(msg)

    for i, r in enumerate(resp.responses):
        if not r.success:
            bad = reg_tokens[i]
            dt = db.query(DeviceToken).filter(DeviceToken.token==bad).first()
            if dt:
                dt.is_active = False
    db.commit()
    return resp.success_count
