import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/api.dart';
import '../../state/session_state.dart';
import '../../state/case_state.dart';
import '../../widgets/dome_appbar.dart';

class TimelineEvent {
  final String id, statusText, occurredAt, source;
  final String? plainExplanation;

  TimelineEvent({
    required this.id,
    required this.statusText,
    required this.occurredAt,
    required this.source,
    this.plainExplanation,
  });

  factory TimelineEvent.fromJson(Map<String, dynamic> j) => TimelineEvent(
        id: j["id"],
        statusText: j["status_text"] ?? "",
        occurredAt: j["occurred_at"],
        source: j["source"] ?? "TORCH",
        plainExplanation: j["plain_explanation"],
      );
}

class CaseTimelineScreen extends StatefulWidget {
  const CaseTimelineScreen({super.key});
  @override
  State<CaseTimelineScreen> createState() => _CaseTimelineScreenState();
}

class _CaseTimelineScreenState extends State<CaseTimelineScreen> {
  bool loading = true;
  String? error;
  String? receipt;
  String? latest;
  List<TimelineEvent> events = [];

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final s = context.read<SessionState>();
      final cs = context.read<CaseState>();
      final res = await Api.get("/v1/timeline/cases/${cs.caseId}", s);
      if (res.statusCode != 200) throw Exception(res.body);
      final data = jsonDecode(res.body);
      receipt = data["receipt_number"];
      latest = data["latest_status"];
      final list = (data["events"] as List).cast<Map<String, dynamic>>();
      events = list.map(TimelineEvent.fromJson).toList();
    } catch (e) {
      error = "$e";
    } finally {
      setState(() => loading = false);
    }
  }

  Future<void> pollNow() async {
    final s = context.read<SessionState>();
    final cs = context.read<CaseState>();
    await Api.post("/v1/cases/${cs.caseId}/poll-status", s, {});
    await load();
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => load());
  }

  @override
  Widget build(BuildContext context) {
    final cs = context.watch<CaseState>();
    return Scaffold(
      appBar: DomeAppBar(title: "Case Timeline", progress: 1.0, onBack: () => Navigator.pop(context)),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text(error!, textAlign: TextAlign.center))
              : RefreshIndicator(
                  onRefresh: load,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      if (receipt != null) Text("Receipt: $receipt", style: TextStyle(color: Colors.grey.shade700)),
                      if (latest != null) ...[
                        const SizedBox(height: 6),
                        Text("Latest: $latest", style: const TextStyle(fontWeight: FontWeight.w800)),
                      ],
                      const SizedBox(height: 12),
                      if (events.isEmpty)
                        const Padding(
                          padding: EdgeInsets.only(top: 60),
                          child: Center(child: Text("No status history yet.")),
                        ),
                      ...List.generate(events.length, (i) {
                        final e = events[i];
                        final isLast = i == events.length - 1;
                        return _TimelineTile(event: e, isLast: isLast);
                      }),
                    ],
                  ),
                ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: pollNow,
        icon: const Icon(Icons.refresh),
        label: const Text("Check Now"),
      ),
    );
  }
}

class _TimelineTile extends StatelessWidget {
  final TimelineEvent event;
  final bool isLast;
  const _TimelineTile({required this.event, required this.isLast});

  @override
  Widget build(BuildContext context) {
    final date = DateTime.tryParse(event.occurredAt);
    final when = date == null
        ? event.occurredAt
        : "${date.month}/${date.day}/${date.year} ${date.hour.toString().padLeft(2,'0')}:${date.minute.toString().padLeft(2,'0')}";

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            Container(
              width: 14,
              height: 14,
              margin: const EdgeInsets.only(top: 6),
              decoration: const BoxDecoration(color: Colors.deepPurple, shape: BoxShape.circle),
            ),
            if (!isLast) Container(width: 2, height: 80, color: Color(0xFFE1BEE7)),
          ],
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(event.statusText, style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(when, style: TextStyle(color: Colors.grey.shade700, fontSize: 12)),
                  if (event.plainExplanation != null) ...[
                    const SizedBox(height: 6),
                    Text(event.plainExplanation!),
                  ],
                  const SizedBox(height: 6),
                  Text("Source: ${event.source}", style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                ],
              ),
            ),
          ),
        )
      ],
    );
  }
}
