from sqlalchemy import Column, String, DateTime, ForeignKey, Boolean, JSON, Index
from datetime import datetime
import uuid
from .db import Base

def uid(): return str(uuid.uuid4())

class CaseBilling(Base):
    __tablename__ = "case_billing"
    id = Column(String, primary_key=True, default=uid)
    case_id = Column(String, index=True)
    user_id = Column(String, ForeignKey("users.id"), index=True)

    stripe_customer_id = Column(String, nullable=True)
    stripe_subscription_id = Column(String, nullable=True)
    last_checkout_session_id = Column(String, nullable=True)
    last_payment_mode = Column(String, nullable=True)  # subscription | payment

    is_active = Column(Boolean, default=False)
    ended_reason = Column(String, nullable=True)  # approved | denied | canceled_by_user | failed

    meta_jsonb = Column(JSON, default={})
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)

Index("ix_case_billing_case_user", CaseBilling.case_id, CaseBilling.user_id)
