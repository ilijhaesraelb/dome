import stripe
from datetime import datetime
from fastapi import APIRouter, Request, HTTPException, Depends
from sqlalchemy.orm import Session
from .db import get_db
from .settings import settings
from .models_billing import CaseBilling

stripe.api_key = settings.STRIPE_SECRET_KEY
router = APIRouter(prefix="/v1/webhooks", tags=["webhooks"])

@router.post("/stripe")
async def stripe_webhook(req: Request, db: Session = Depends(get_db)):
    payload = await req.body()
    sig = req.headers.get("stripe-signature")

    if not settings.STRIPE_WEBHOOK_SECRET:
        raise HTTPException(500, "Missing STRIPE_WEBHOOK_SECRET")

    try:
        event = stripe.Webhook.construct_event(payload, sig, settings.STRIPE_WEBHOOK_SECRET)
    except Exception as e:
        raise HTTPException(400, f"Invalid webhook signature: {e}")

    etype = event["type"]
    obj = event["data"]["object"]

    if etype == "checkout.session.completed":
        meta = obj.get("metadata") or {}
        billing_id = meta.get("billing_id")
        if billing_id:
            b = db.query(CaseBilling).filter(CaseBilling.id==billing_id).first()
            if b:
                b.meta_jsonb = {**(b.meta_jsonb or {}), "checkout_completed": True}
                if obj.get("mode") == "subscription" and obj.get("subscription"):
                    b.stripe_subscription_id = obj["subscription"]
                    b.is_active = True
                b.updated_at = datetime.utcnow()
                db.commit()

    if etype.startswith("customer.subscription."):
        sub_id = obj["id"]
        b = db.query(CaseBilling).filter(CaseBilling.stripe_subscription_id==sub_id).first()
        if b:
            status = obj.get("status")
            b.meta_jsonb = {**(b.meta_jsonb or {}), "stripe_status": status}
            if etype == "customer.subscription.deleted" or status in ("canceled", "unpaid", "incomplete_expired"):
                b.is_active = False
                if not b.ended_reason:
                    b.ended_reason = "failed" if status in ("unpaid", "incomplete_expired") else "canceled_by_user"
            b.updated_at = datetime.utcnow()
            db.commit()

    if etype == "invoice.payment_failed":
        sub_id = obj.get("subscription")
        if sub_id:
            b = db.query(CaseBilling).filter(CaseBilling.stripe_subscription_id==sub_id).first()
            if b:
                b.meta_jsonb = {**(b.meta_jsonb or {}), "last_payment_failed": True}
                b.updated_at = datetime.utcnow()
                db.commit()

    return {"received": True}
