import 'package:firebase_messaging/firebase_messaging.dart';
import '../state/session_state.dart';
import 'api.dart';

class PushRegister {
  static Future<void> initAndRegister(SessionState s) async {
    final fm = FirebaseMessaging.instance;
    await fm.requestPermission(alert: true, badge: true, sound: true);

    final token = await fm.getToken();
    if (token == null) return;

    await Api.post("/v1/notify/register", s, {"token": token, "platform": "mobile"});

    FirebaseMessaging.onMessageOpenedApp.listen((m) {
      // TODO: route to case page using m.data["case_id"]
    });
  }
}
