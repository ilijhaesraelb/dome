import time, random, requests
from typing import Dict, Any, Optional
from ..settings import settings

class TorchClient:
    def __init__(self):
        self._token: Optional[str] = None
        self._exp: float = 0.0

    @property
    def token_url(self) -> str:
        return settings.TORCH_TOKEN_URL_PROD if settings.TORCH_ENV == "prod" else settings.TORCH_TOKEN_URL_SANDBOX

    @property
    def base_url(self) -> str:
        return settings.TORCH_BASE_URL_PROD if settings.TORCH_ENV == "prod" else settings.TORCH_BASE_URL_SANDBOX

    def _refresh_token(self) -> None:
        resp = requests.post(
            self.token_url,
            data={"grant_type": "client_credentials"},
            auth=(settings.TORCH_CLIENT_ID, settings.TORCH_CLIENT_SECRET),
            timeout=20,
        )
        resp.raise_for_status()
        data = resp.json()
        self._token = data["access_token"]
        self._exp = time.time() + int(data.get("expires_in", 3600)) - 60

    def get_token(self) -> str:
        if not self._token or time.time() > self._exp:
            self._refresh_token()
        assert self._token
        return self._token

    def request(self, method: str, path: str, params=None, json_body=None,
                max_retries: int = 5, base_delay: float = 0.8) -> Dict[str, Any]:
        headers = {"Authorization": f"Bearer {self.get_token()}"}
        url = self.base_url.rstrip("/") + path

        last_err: Exception | None = None
        for attempt in range(max_retries):
            try:
                r = requests.request(method, url, headers=headers, params=params, json=json_body, timeout=25)
                if r.status_code in (429, 500, 502, 503, 504):
                    raise requests.HTTPError(f"retryable {r.status_code}: {r.text}")
                r.raise_for_status()
                return r.json()
            except Exception as e:
                last_err = e
                delay = base_delay * (2 ** attempt)
                jitter = random.uniform(0, delay * 0.25)
                time.sleep(delay + jitter)

        raise last_err if last_err else RuntimeError("Torch request failed")  # pragma: no cover

torch_client = TorchClient()
